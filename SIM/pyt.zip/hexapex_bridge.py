#!/usr/bin/env python3
"""HEXApex bridge: connects the simulator to the apps on your PC.

  * Click a pad key in the simulator  -> the shortcut is pressed in the app you were using
    (EasyEDA, VS Code, ...). The "@GitLab" key opens your repo's GitLab page.
  * Press a shortcut anywhere on your keyboard -> the matching pad key lights up.

Setup:   pip install pynput
Run:     python hexapex_bridge.py      (keep hexapex_simulator.html in the same folder)
Options: set HEXAPEX_REPO to your project folder (for the GitLab key) and HEXAPEX_PORT to change the port.
"""
import json, os, queue, re, secrets, subprocess, sys, threading, time, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    from pynput import keyboard
    from pynput.keyboard import Key, KeyCode
except ImportError:
    sys.exit("Missing dependency. Run:  pip install pynput")

PORT = int(os.environ.get("HEXAPEX_PORT", 8765))
REPO = os.environ.get("HEXAPEX_REPO", os.getcwd())
HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN = secrets.token_urlsafe(16)          # only the page served by this script knows it
WIN, MAC = sys.platform == "win32", sys.platform == "darwin"

kb = keyboard.Controller()
MODS = {"ctrl": Key.ctrl, "shift": Key.shift, "alt": Key.alt}
SPECIAL = {"space": Key.space, "enter": Key.enter, "home": Key.home, "end": Key.end,
           "left": Key.left, "right": Key.right, "esc": Key.esc, "f5": Key.f5}
held, clients, lock = {}, [], threading.Lock()


def parse(combo):
    """'Ctrl+Shift+G' -> ([Key.ctrl, Key.shift], 'g'). Only simple shortcuts are accepted."""
    parts = [p.lower() for p in combo.split("+")]
    key, mods = parts[-1], parts[:-1]
    if any(m not in MODS for m in mods):
        return None
    if key in SPECIAL:
        key = SPECIAL[key]
    elif key == "plus":
        key = KeyCode.from_vk(0xBB) if WIN else "="
    elif key == "minus":
        key = KeyCode.from_vk(0xBD) if WIN else "-"
    elif not re.fullmatch(r"[a-z0-9]", key):
        return None
    return [MODS[m] for m in mods], key


def switch_back():
    """Clicking the simulator focused its window; Alt+Tab returns to the app you were using."""
    m = Key.cmd if MAC else Key.alt
    kb.press(m); time.sleep(.03); kb.press(Key.tab); kb.release(Key.tab); time.sleep(.03); kb.release(m)
    time.sleep(.3)


def gitlab_url():
    try:
        u = subprocess.check_output(["git", "-C", REPO, "remote", "get-url", "origin"],
                                    text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return None
    u = re.sub(r"^(ssh://)?git@([^:/]+)[:/]", r"https://\2/", u)
    u = re.sub(r"//[^@/]+@", "//", u)
    return re.sub(r"\.git$", "", u)


def send(kind, combo, refocus):
    with lock:
        if combo.lower() == "@gitlab":
            if kind == "down":
                url = gitlab_url()
                webbrowser.open(url) if url else print("No git remote found in", REPO)
        elif kind == "down":
            p = parse(combo)
            if not p or combo in held:
                return
            if refocus:
                switch_back()
            mods, key = p
            for m in mods: kb.press(m)
            kb.press(key)
            held[combo] = p
        elif combo in held:
            mods, key = held.pop(combo)
            kb.release(key)
            for m in reversed(mods): kb.release(m)


def release_all():
    with lock:
        for mods, key in held.values():
            kb.release(key)
            for m in reversed(mods): kb.release(m)
        held.clear()


# ---- global key listener: tells the page which shortcuts you press in any app
mods_down = {"ctrl": False, "shift": False, "alt": False}


def name(k):
    if isinstance(k, Key):
        n = k.name
        for m in mods_down:
            if n.startswith(m): return m
        return ("ctrl" if MAC else "win") if n.startswith("cmd") else n
    vk = getattr(k, "vk", None)
    if WIN and vk is not None:
        if 0x41 <= vk <= 0x5A or 0x30 <= vk <= 0x39: return chr(vk).lower()
        return {0xBB: "plus", 0x6B: "plus", 0xBD: "minus", 0x6D: "minus"}.get(vk)
    c = getattr(k, "char", None)
    return c.lower() if c else None


def listener(is_down):
    def cb(k):
        n = name(k)
        if not n: return
        if n in mods_down: mods_down[n] = is_down
        ev = "data: " + json.dumps({"d": int(is_down), "k": n, "c": int(mods_down["ctrl"]),
                                    "a": int(mods_down["alt"]), "s": int(mods_down["shift"])}) + "\n\n"
        for q in list(clients): q.put(ev)
    return cb


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def host_ok(self):   # blocks other sites from talking to this server
        return self.headers.get("Host", "") in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def do_GET(self):
        if not self.host_ok(): return self.send_error(403)
        if self.path.split("?")[0] == "/":
            html = open(os.path.join(HERE, "hexapex_simulator.html"), encoding="utf-8").read()
            body = html.replace("<!--BRIDGE-->", f'<script>window.BRIDGE_TOKEN="{TOKEN}"</script>').encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body)
        elif self.path == "/events?token=" + TOKEN:
            q = queue.Queue(); clients.append(q)
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            try:
                self.wfile.write(b": hello\n\n"); self.wfile.flush()
                while True:
                    try: self.wfile.write(q.get(timeout=15).encode())
                    except queue.Empty: self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
            except OSError:
                pass
            finally:
                clients.remove(q); release_all()
        else:
            self.send_error(404)

    def do_POST(self):
        if not self.host_ok() or self.path != "/key" or self.headers.get("X-Token") != TOKEN:
            return self.send_error(403)
        try:
            d = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
            send(d["t"], str(d["c"]), bool(d.get("f")))
        except Exception as e:
            print("bad request:", e)
        self.send_response(204); self.end_headers()


if __name__ == "__main__":
    keyboard.Listener(on_press=listener(True), on_release=listener(False)).start()
    url = f"http://127.0.0.1:{PORT}/"
    print(f"HEXApex bridge running at {url}\nGitLab key uses the repo in: {REPO}\nPress Ctrl+C here to stop.")
    threading.Timer(.8, lambda: webbrowser.open(url)).start()
    try:
        ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        release_all()
